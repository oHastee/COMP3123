const numberArray = [1, 60, 34, 30, 20, 5];

const filteredNumbers = numberArray.filter(num => num < 20);

console.log(filteredNumbers);
